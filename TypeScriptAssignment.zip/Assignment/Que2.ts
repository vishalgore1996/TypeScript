// "2) create a class name shape and create two sub class rectangle and square
//depending upon the object call print the area of square"
class Shape
{
area:number;
  disp()
  {
	console.log("This is area of Square="+this.area);
  }
  disp1()
  {
	console.log("This is area of Rectangle="+this.area);
  }
  
}
class Square extends Shape
{
	
	side:number;
	constructor(side:number)
	{
		super();
		this.side=side;
		
	}
	Area()
	{
		this.area=this.side * this.side;
		this.disp();
	}	
}
class Rectangle extends Shape
{
	
	l:number;
	b:number;
	constructor(l:number,b:number)
	{
		super();
		this.b=b;
		this.l=l;
		
	}
	Area()
	{
		this.area=this.l * this.b;
		this.disp1();
	}	
}


var objSquare = new Square(10);
objSquare.Area();

var objRectangle= new Rectangle(10,20);
objRectangle.Area();


