var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// "2) create a class name shape and create two sub class rectangle and square
//depending upon the object call print the area of square"
var Shape = /** @class */ (function () {
    function Shape() {
    }
    Shape.prototype.disp = function () {
        console.log("This is area of Square=" + this.area);
    };
    Shape.prototype.disp1 = function () {
        console.log("This is area of Rectangle=" + this.area);
    };
    return Shape;
}());
var Square = /** @class */ (function (_super) {
    __extends(Square, _super);
    function Square(side) {
        var _this = _super.call(this) || this;
        _this.side = side;
        return _this;
    }
    Square.prototype.Area = function () {
        this.area = this.side * this.side;
        this.disp();
    };
    return Square;
}(Shape));
var Rectangle = /** @class */ (function (_super) {
    __extends(Rectangle, _super);
    function Rectangle(l, b) {
        var _this = _super.call(this) || this;
        _this.b = b;
        _this.l = l;
        return _this;
    }
    Rectangle.prototype.Area = function () {
        this.area = this.l * this.b;
        this.disp1();
    };
    return Rectangle;
}(Shape));
var objSquare = new Square(10);
objSquare.Area();
var objRectangle = new Rectangle(10, 20);
objRectangle.Area();
