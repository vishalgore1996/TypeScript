// 1) need to create a list of marks and arrange them using arrow funciton
/*class Student {
    m1: number;
    m2: number;
    m3: number;
    m4: number;
    stdName: string;

    constructor(m1: number,m2: number,m3: number,m4 :number, stdName: string) {
       this.m1=m1;
       this.m2=m2;
       this.m3=m3;
       this.m4=m4;
       this.stdName=stdName;
    }

    display = () => console.log(this.m1 +' ' + this.m2+' '+this.m3+' '+this.m4+' '+this.stdName)
}
let std = new Student(50,60,70,80,'Vishal');
std.display();
*/
var marks = [40, 60, 30, 20, 35, 21];
marks.sort(function (a, b) { return a - b; });
console.log(marks);
